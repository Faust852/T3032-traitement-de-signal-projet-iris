import cv2
import numpy as np
import Image
import utils
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

## Read Image
image2 = cv2.imread('S1001R06.jpg')
image = cv2.imread('iris14.jpg')

imageBackup = image.copy()

## Convert to 1 channel only grayscale image
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
## CLAHE Equalization



cl1 = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
clahe = cl1.apply(gray)
## medianBlur the image to remove noise
medianblur = cv2.medianBlur(clahe, 15)
blur = cv2.medianBlur(medianblur, 15)



edges = cv2.Canny(blur, 30, 60)

## Detect Circles
circles = cv2.HoughCircles(edges , cv2.cv.CV_HOUGH_GRADIENT,1,3000,
                            param1=30,param2=15,minRadius=20,maxRadius=200)

for circle in circles[0,:]:
    # draw the outer circle
    cv2.circle(image,(circle[0],circle[1]),circle[2],(0,255,0),2)

    # draw the center of the circle
    cv2.circle(image,(circle[0],circle[1]),2,(0,0,255),3)
    print int(circle[0])
    print int(circle[1])
    print int(circle[2])
    x1 = int(circle[0] - circle[2]-15)
    y1 = int(circle[1] - circle[2]-15)
    x2 = int(circle[0] + circle[2]+15)
    y2 = int(circle[1] + circle[2]+15)

    crop = imageBackup[y1:y2,x1:x2]
    #if crop is not None:
        #cv2.imshow('test', crop)




cv2.imshow('Final', image)
cv2.imshow('Edges', edges)
cv2.imshow('clahe', clahe)
cv2.imshow('Mediam', medianblur)
cv2.imshow('Blur', blur)

cv2.imshow('imageBackup', imageBackup)


cv2.waitKey(0)
cv2.destroyAllWindows()